import { NgModule } from '@angular/core';
import { BrowserModule } from '@angular/platform-browser';
import { ReactiveFormsModule } from '@angular/forms';
import { HttpClientModule } from '@angular/common/http';

import { AppRoutingModule } from './app-routing.module';

import { AppComponent } from './app.component';

import { PagosModule } from './pagos/pagos.module';
import { AuditoriasModule } from './auditorias/auditorias.module';
import { ContratosModule } from './contratos/contratos.module';

@NgModule({
  declarations: [AppComponent],
  imports: [
    BrowserModule,
    AppRoutingModule,
    ReactiveFormsModule,
    HttpClientModule,
    PagosModule,
    AuditoriasModule,
    ContratosModule
  ],
  providers: [],
  bootstrap: [AppComponent]
})
export class AppModule {}
