export const environment = {
  production: true,
  backendApiUrl: 'https://api.miapp.com/api'
};
