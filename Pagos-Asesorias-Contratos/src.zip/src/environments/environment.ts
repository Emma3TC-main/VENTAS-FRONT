export const environment = {
  production: false,
  backendApiUrl: 'http://localhost:8080/api'
};
